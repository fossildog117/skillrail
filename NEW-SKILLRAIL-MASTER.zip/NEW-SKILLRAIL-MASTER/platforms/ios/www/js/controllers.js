angular.module('app.controllers', [])
  
.controller('loginCtrl', function($scope) {

})
      
.controller('name+LastNameOfUserCtrl', function($scope) {

})
   
.controller('homeCtrl', function($scope) {

})
   
.controller('myProposalsCtrl', function($scope) {

})
   
.controller('browseJobsCtrl', function($scope) {

})
   
.controller('messagesCtrl', function($scope) {

})
   
.controller('activeJobsCtrl', function($scope) {

})
   
.controller('createStudentProfile(1)Ctrl', function($scope) {

})
   
.controller('createStudentProfile(2)Ctrl', function($scope) {

})
   
.controller('createStudentProfile(3)Ctrl', function($scope) {

})
   
.controller('jobsCtrl', function($scope) {

})
   
.controller('jobDetailsCtrl', function($scope) {

})
   
.controller('createAccountCtrl', function($scope) {

})
 