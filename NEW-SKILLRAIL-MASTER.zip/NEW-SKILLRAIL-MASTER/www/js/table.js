angular.module('app.table', ['ionic'])

  // Student factory

.controller('tableController', function($scope) {

  //$scope.students = [
  //
  //  {name: 'Nathan', description: 'I am a student studying computer science at UCL, I am looking for a job'},
  //  {name: 'Romain', description: 'I am a student studying computer science, I am looking for a job'},
  //  {name: 'Peter', description: 'I am a student studying asteroid student, I am looking for a part time job'},
  //  {name: 'Bill', description: 'I am a student studying biology science, I am looking for a job'}];

});

